# Sentinel — A Zero Trust Access Control Architecture for Enterprise Environments

A containerized Zero Trust security lab demonstrating "never trust, always
verify" principles — MFA-enforced identity verification (Keycloak),
centralized policy enforcement (Traefik), RBAC-based access control, and
Docker-based micro-segmentation. Validated through simulated insider and
external threat testing.

Minor Project 2 — B.Sc. Computer Science, JSPM University Pune.

---

## Architecture

```
Internet ──> Traefik (PEP) ──> forward-auth ──> Keycloak (IdP, MFA/TOTP)
                 │
                 ├── /admin  ──> admin-app   (backend-admin network, internal)
                 ├── /dev    ──> dev-app     (backend-dev network, internal)
                 └── /       ──> public-app  (frontend network)
```

Every request hits Traefik first. Traefik forwards it to `forward-auth`,
which checks the session against Keycloak (OIDC). Unauthenticated requests
are redirected to log in; authenticated requests carry role claims that
gate access to `/admin` and `/dev`. `admin-app` and `dev-app` sit on
**separate, `internal: true` Docker networks** — they cannot reach each
other directly, and neither has direct internet egress. Traefik is the
only component bridging into both, simulating micro-segmentation with a
single, auditable enforcement point.

## Tech stack

| Component        | Purpose                                      |
|-------------------|-----------------------------------------------|
| Keycloak          | Identity Provider (IdP), MFA/TOTP, RBAC roles |
| Traefik           | Reverse proxy / Policy Enforcement Point (PEP)|
| traefik-forward-auth | OIDC session verification middleware       |
| Docker / Compose  | Service isolation, micro-segmentation         |
| Nginx             | Sample backend services (admin/dev/public)    |
| Python (optional) | Scriptable threat-simulation smoke tests      |

## Prerequisites & installation

You need **Docker** and **Docker Compose** installed. Everything else
(Keycloak, Traefik, etc.) runs as containers — nothing else is installed
on your host.

### 1. Install Docker

**Windows / macOS** — install Docker Desktop:
```bash
# https://www.docker.com/products/docker-desktop/
# Download and run the installer, then verify:
docker --version
docker compose version
```

**Linux (Ubuntu/Debian)**:
```bash
sudo apt update
sudo apt install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo $VERSION_CODENAME) stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
sudo usermod -aG docker $USER   # log out/in after this
docker --version
docker compose version
```

### 2. Clone the repo

```bash
git clone https://github.com/<your-username>/sentinel-zero-trust.git
cd sentinel-zero-trust
```

### 3. (Optional) Python environment for test scripts

Only needed if you run the scripted smoke tests in `tests/` instead of
testing manually via browser/curl.

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 4. Start the stack

```bash
docker compose up -d
```

Check everything is healthy:
```bash
docker compose ps
docker compose logs -f keycloak
```

## Using the lab

1. **Keycloak admin console** — `http://localhost:8080`
   Login: `admin` / `admin_change_me`
   Confirm the `zero-trust-lab` realm imported with three demo users:
   - `alice-admin` — role: `admin`
   - `bob-dev` — role: `developer`
   - `carol-guest` — role: none
   All passwords: `ChangeMe123!` (forced to set up TOTP/MFA on first login)

2. **Try the protected routes**:
   - `http://localhost/admin` — should only succeed for `alice-admin`
   - `http://localhost/dev` — should only succeed for `bob-dev`
   - `http://localhost/` — any authenticated user

3. **Traefik dashboard** — `http://localhost:8081`

## Threat simulation testing

Documented in `tests/` as setup → attempt → expected vs. actual →
screenshot:

- **External threat** — attempt to reach `admin-app`/`dev-app` directly,
  bypassing Traefik (should fail — networks are `internal`, not published)
- **Insider threat / privilege escalation** — log in as `bob-dev` and
  request `/admin` (should be denied)
- **Lateral movement** — `docker exec` into `admin-app`, attempt to reach
  `dev-app` (should fail — no shared network)
- **MFA bypass** — attempt login with password only before TOTP enrollment
  (should be blocked by `CONFIGURE_TOTP` required action)

## Stopping / resetting

```bash
docker compose down          # stop containers, keep data
docker compose down -v       # stop and wipe all volumes (full reset)
```

## Repo layout

```
sentinel-zero-trust/
├── docker-compose.yml
├── requirements.txt
├── LICENSE
├── keycloak/realm-export.json     # roles, MFA policy, demo users
├── traefik/dynamic.yml            # PEP middlewares (auth + RBAC)
├── apps/{admin,dev,public}/       # sample backend services
└── tests/                         # threat-simulation writeups + scripts
```

## Known limitations (documented, not hidden)

- **RBAC enforcement is lab-scale**: the `require-*-role` middlewares in
  `traefik/dynamic.yml` inject a header but don't yet cryptographically
  verify the JWT's role claim. A production build should replace this
  with an **Open Policy Agent (OPA)** sidecar validating
  `realm_access.roles` from the token directly.
- **TLS is omitted** for lab simplicity (`INSECURE_COOKIE=true`, plain
  HTTP). A real deployment needs TLS on every hop.
- Default secrets/passwords in this repo are placeholders for local
  testing only — rotate them before any real deployment, and never
  commit real secrets to a public repo.

## License

MIT — see [LICENSE](./LICENSE).
